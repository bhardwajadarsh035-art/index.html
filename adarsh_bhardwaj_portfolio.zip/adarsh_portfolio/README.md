# Adarsh Bhardwaj — Portfolio

Responsive dark-theme portfolio built with HTML, CSS, and JavaScript.

## Preview
Extract the ZIP and open `index.html` in your browser.

## Publish with GitHub Pages
1. Create a public GitHub repository, e.g. `adarsh-portfolio`.
2. Upload `index.html` to the repository root and commit.
3. Go to Settings → Pages.
4. Choose Deploy from a branch, branch `main`, folder `/(root)`, then Save.
5. Wait for GitHub Pages to publish your URL.

The LinkedIn button is a generic link until you replace it with Adarsh's profile URL.
